<template>
  <div class="about">
    <marquee>
      <h1>NEWS TICKER ......NEWS TICKER......NEWS TICKER ......NEWS TICKER.......NEWS TICKER</h1>
    </marquee>
    <h2>Created by: Arjun Yadav ,Bhomit kapoor ,Karan sethi</h2>
  </div>
</template>

<script>
export default {
  name: "About"
};
</script>
<style>
h2 {
  margin-top: 300px;
  color: red;
}
</style>